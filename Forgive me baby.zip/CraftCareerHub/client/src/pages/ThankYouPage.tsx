import { useLocation } from "wouter";
import { useState, useEffect } from "react";
import kissingPandas from "@assets/bubu-dudu-kiss.gif";

const ThankYouPage = () => {
  const [location, setLocation] = useLocation();
  const [confetti, setConfetti] = useState<JSX.Element[]>([]);
  
  useEffect(() => {
    // Generate confetti elements on component mount
    const colors = ['#fd1853', '#8a2be2', '#ffcc00', '#33cc33', '#3399ff', '#ff66cc', '#ff9999', '#ffb3e6', '#9999ff'];
    
    // Create various confetti shapes
    const shapes = [
      // Round confetti
      ...Array.from({ length: 80 }).map((_, i) => {
        const color = colors[Math.floor(Math.random() * colors.length)];
        const size = Math.floor(Math.random() * 10) + 5;
        const left = `${Math.random() * 100}%`;
        const duration = `${Math.random() * 5 + 3}s`;
        const delay = `${Math.random() * 3}s`;
        
        return (
          <div 
            key={`circle-${i}`}
            className="absolute rounded-full opacity-70"
            style={{
              backgroundColor: color,
              width: `${size}px`,
              height: `${size}px`,
              left: left,
              top: '-5%',
              animation: `confetti-fall ${duration} linear forwards`,
              animationDelay: delay,
              zIndex: 10
            }}
          />
        );
      }),
      
      // Star-shaped confetti
      ...Array.from({ length: 30 }).map((_, i) => {
        const color = colors[Math.floor(Math.random() * colors.length)];
        const size = Math.floor(Math.random() * 12) + 8;
        const left = `${Math.random() * 100}%`;
        const duration = `${Math.random() * 6 + 4}s`;
        const delay = `${Math.random() * 3}s`;
        const rotate = Math.random() * 360;
        
        return (
          <div 
            key={`star-${i}`}
            className="absolute opacity-80"
            style={{
              color: color,
              fontSize: `${size}px`,
              left: left,
              top: '-5%',
              transform: `rotate(${rotate}deg)`,
              animation: `confetti-fall ${duration} linear forwards`,
              animationDelay: delay,
              zIndex: 10
            }}
          >
            ★
          </div>
        );
      }),
      
      // Heart-shaped confetti
      ...Array.from({ length: 50 }).map((_, i) => {
        const color = colors[Math.floor(Math.random() * colors.length)];
        const size = Math.floor(Math.random() * 12) + 8;
        const left = `${Math.random() * 100}%`;
        const duration = `${Math.random() * 5 + 3}s`;
        const delay = `${Math.random() * 3}s`;
        const rotate = Math.random() * 360;
        
        return (
          <div 
            key={`heart-${i}`}
            className="absolute opacity-80"
            style={{
              color: color,
              fontSize: `${size}px`,
              left: left,
              top: '-5%',
              transform: `rotate(${rotate}deg)`,
              animation: `confetti-fall ${duration} linear forwards`,
              animationDelay: delay,
              zIndex: 10
            }}
          >
            ❤
          </div>
        );
      }),
    ];
    
    setConfetti(shapes);
  }, []);

  const handleBackClick = () => {
    setLocation("/");
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center relative overflow-hidden"
         style={{ background: "linear-gradient(135deg, #fffbf7 0%, #fff0f7 100%)" }}>
      {/* Background decorative elements */}
      <div className="absolute inset-0 z-0">
        {Array.from({ length: 8 }).map((_, i) => (
          <div
            key={`bg-element-${i}`}
            className="absolute rounded-full"
            style={{
              background: `radial-gradient(circle, rgba(255,182,193,0.4) 0%, rgba(255,182,193,0) 70%)`,
              width: `${Math.random() * 400 + 200}px`,
              height: `${Math.random() * 400 + 200}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              transform: 'translate(-50%, -50%)',
              opacity: 0.6,
            }}
          />
        ))}
      </div>
      
      {/* Floating balloons */}
      {Array.from({ length: 12 }).map((_, i) => (
        <div
          key={`balloon-${i}`}
          className="absolute z-0"
          style={{
            fontSize: `${Math.random() * 25 + 30}px`,
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 40 + 5}%`,
            opacity: 0.7,
            animation: `float ${Math.random() * 10 + 15}s ease-in-out infinite`,
            animationDelay: `${Math.random() * 7}s`,
            transform: `rotate(${Math.random() * 10 - 5}deg)`,
            color: [
              '#ff9999', '#ff99cc', '#cc99ff', '#9999ff', 
              '#99ccff', '#99ffcc', '#ffff99', '#ffcc99'
            ][Math.floor(Math.random() * 8)]
          }}
        >
          🎈
        </div>
      ))}
      
      {/* Floating hearts */}
      {Array.from({ length: 15 }).map((_, i) => (
        <div
          key={`float-heart-${i}`}
          className="absolute z-0"
          style={{
            fontSize: `${Math.random() * 15 + 15}px`,
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            opacity: 0.5,
            animation: `float ${Math.random() * 8 + 10}s ease-in-out infinite`,
            animationDelay: `${Math.random() * 5}s`,
            transform: `rotate(${Math.random() * 180}deg)`,
            color: `hsl(${340 + Math.random() * 40}, ${90 + Math.random() * 10}%, ${70 + Math.random() * 20}%)`
          }}
        >
          ❤
        </div>
      ))}
      
      {/* Confetti elements */}
      {confetti}
      
      <div className="container mx-auto px-4 py-8 max-w-md z-10">
        <div className="flex flex-col items-center justify-center p-6 bg-white rounded-2xl shadow-lg"
             style={{ backgroundColor: "rgba(255, 255, 255, 0.85)", backdropFilter: "blur(8px)" }}>
          <h1 className="text-2xl md:text-3xl font-semibold text-gray-800 mb-4 text-center">
            谢谢宝，我爱你&lt;3
          </h1>
          
          <div className="w-full mb-8 flex justify-center">
            <img 
              src={kissingPandas} 
              alt="Pandas kissing" 
              className="w-48 h-48 object-contain rounded-lg"
            />
          </div>
          
          <button 
            id="backBtn"
            className="btn bg-[hsl(40,100%,80%)] hover:bg-yellow-400 text-gray-700 font-bold py-3 px-6 rounded-full text-lg shadow-md"
            onClick={handleBackClick}
          >
            返回
          </button>
        </div>
      </div>
    </div>
  );
};

export default ThankYouPage;
