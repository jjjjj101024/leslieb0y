import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import cryingPanda from "@assets/bub cry 2.gif";

const HomePage = () => {
  const [location, setLocation] = useLocation();
  const [okButtonSize, setOkButtonSize] = useState(1);
  const noButtonRef = useRef<HTMLButtonElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const growthRate = 0.25; // Even higher growth rate

  const moveNoButton = () => {
    if (noButtonRef.current && containerRef.current) {
      const containerWidth = containerRef.current.offsetWidth - noButtonRef.current.offsetWidth;
      const containerHeight = containerRef.current.offsetHeight - noButtonRef.current.offsetHeight;
      
      // Calculate boundaries to keep button within container
      const maxX = containerWidth * 0.8;
      const maxY = containerHeight * 0.8;
      
      const randomX = Math.random() * maxX;
      const randomY = Math.random() * maxY;
      
      noButtonRef.current.style.position = 'absolute';
      noButtonRef.current.style.left = `${randomX}px`;
      noButtonRef.current.style.top = `${randomY}px`;
      
      // Grow the OK button with no limit
      setOkButtonSize(prev => prev + growthRate);
    }
  };

  const handleOkClick = () => {
    setLocation("/thank-you");
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center relative overflow-hidden" 
         style={{ background: "linear-gradient(135deg, #ffefef 0%, #ffe5ec 100%)" }}>
      {/* Large decorative hearts in the background */}
      {Array.from({ length: 5 }).map((_, i) => (
        <div
          key={`big-heart-${i}`}
          className="absolute text-pink-200 opacity-20 z-0"
          style={{
            top: `${Math.random() * 100}%`,
            left: `${Math.random() * 100}%`,
            fontSize: `${Math.random() * 30 + 70}px`,
            transform: `rotate(${Math.random() * 360}deg)`,
            animation: `float ${Math.random() * 15 + 20}s ease-in-out infinite`,
            animationDelay: `${Math.random() * 5}s`
          }}
        >
          ❤
        </div>
      ))}
      
      {/* Medium floating hearts - reduced quantity */}
      {Array.from({ length: 10 }).map((_, i) => (
        <div
          key={`med-heart-${i}`}
          className="absolute z-0"
          style={{
            top: `${Math.random() * 100}%`,
            left: `${Math.random() * 100}%`,
            fontSize: `${Math.random() * 20 + 15}px`,
            transform: `rotate(${Math.random() * 360}deg)`,
            animation: `float ${Math.random() * 10 + 8}s ease-in-out infinite`,
            animationDelay: `${Math.random() * 5}s`,
            color: `hsl(${340 + Math.random() * 40}, ${90 + Math.random() * 10}%, ${70 + Math.random() * 20}%)`,
            opacity: 0.4 + Math.random() * 0.3
          }}
        >
          ❤
        </div>
      ))}
      
      {/* Small floating hearts - reduced quantity */}
      {Array.from({ length: 15 }).map((_, i) => (
        <div
          key={`small-heart-${i}`}
          className="absolute z-0"
          style={{
            top: `${Math.random() * 100}%`,
            left: `${Math.random() * 100}%`,
            fontSize: `${Math.random() * 10 + 8}px`,
            transform: `rotate(${Math.random() * 360}deg)`,
            animation: `float ${Math.random() * 8 + 4}s ease-in-out infinite`,
            animationDelay: `${Math.random() * 5}s`,
            color: `hsl(${340 + Math.random() * 40}, ${90 + Math.random() * 10}%, ${70 + Math.random() * 20}%)`,
            opacity: 0.4 + Math.random() * 0.3
          }}
        >
          ❤
        </div>
      ))}
      <div className="container mx-auto px-4 py-8 max-w-md" ref={containerRef}>
        <div 
          className="flex flex-col items-center justify-center p-6 bg-white rounded-2xl shadow-lg relative"
          style={{ minHeight: "500px", backdropFilter: "blur(5px)", backgroundColor: "rgba(255, 255, 255, 0.8)" }}
        >
          <h1 className="text-2xl md:text-3xl font-semibold text-gray-800 mb-4 text-center">
            对不起，原谅我好吗 :(
          </h1>
          
          <div className="w-full mb-8 flex justify-center">
            <img 
              src={cryingPanda} 
              alt="Crying panda" 
              className="w-48 h-48 object-contain rounded-lg"
            />
          </div>
          
          <div className="flex flex-col w-full space-y-4">
            <button 
              id="okBtn"
              className="btn bg-[hsl(350,100%,88%)] hover:bg-pink-400 text-white font-bold py-3 px-6 rounded-full text-lg shadow-md"
              style={{ transform: `scale(${okButtonSize})` }}
              onClick={handleOkClick}
            >
              OKOK
            </button>
            
            <button 
              id="noBtn"
              ref={noButtonRef}
              className="btn bg-gray-300 hover:bg-gray-400 text-gray-700 font-bold py-3 px-6 rounded-full text-lg shadow-md"
              onClick={moveNoButton}
            >
              不行
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
